Service now is a basic Flask project for IT Service center to effectively manage IT service works
DB of choice was SQLlite as it has bare minimum models size, now it runs on postgres sql, but planning to push to mongoDB with complicated workflows
Need to work on Login and Registration with oauth and sec compliance
CRM to integrate for lead and customer followup workflows

workflows has to be updated...

Code clean up pending

main filr --> app_custdata.py
